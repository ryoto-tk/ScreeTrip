// ============================================================
// api/mapkit-token.js  — Vercel Serverless Function
// MapKit JS JWT をサーバーサイドで署名して返す
// 秘密鍵は Vercel 環境変数にのみ保存される（クライアントに渡らない）
//
// 必要な環境変数（Vercel Dashboard > Settings > Environment Variables）:
//   MAPKIT_PRIVATE_KEY  : p8ファイルの中身をそのままペースト（改行含む）
//   MAPKIT_KEY_ID       : 68WCUFNV32
//   MAPKIT_TEAM_ID      : QW3XS23C8C
//   MAPKIT_ORIGIN       : https://あなたのドメイン.vercel.app
// ============================================================

export const config = { runtime: 'edge' };

export default async function handler(req) {
  // CORS — 自ドメインからのリクエストのみ許可
  const origin = req.headers.get('origin') || '';
  const allowed = process.env.MAPKIT_ORIGIN || '';
  const allowOrigin = (allowed && origin.startsWith(allowed)) ? origin : allowed;

  // OPTIONS プリフライト
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders(allowOrigin),
    });
  }

  try {
    const token = await generateMapKitJWT();
    return new Response(token, {
      status: 200,
      headers: {
        ...corsHeaders(allowOrigin),
        'Content-Type': 'text/plain',
        'Cache-Control': 'private, max-age=1500', // 25分キャッシュ（JWT有効期限30分）
      },
    });
  } catch (err) {
    console.error('MapKit JWT error:', err);
    return new Response('JWT generation failed', { status: 500 });
  }
}

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin':  origin || '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

// ── JWT 生成（Web Crypto API — Edge Runtime 対応）──
async function generateMapKitJWT() {
  const keyId   = process.env.MAPKIT_KEY_ID   || '68WCUFNV32';
  const teamId  = process.env.MAPKIT_TEAM_ID  || 'QW3XS23C8C';
  const rawKey  = process.env.MAPKIT_PRIVATE_KEY || '';

  if (!rawKey) throw new Error('MAPKIT_PRIVATE_KEY is not set');

  const now = Math.floor(Date.now() / 1000);
  const exp = now + 1800; // 30分有効

  // JWT Header
  const header = {
    alg: 'ES256',
    typ: 'JWT',
    kid: keyId,
  };

  // JWT Payload
  const payload = {
    iss: teamId,
    iat: now,
    exp: exp,
    // origin 制限（省略可 — 制限したい場合はコメントアウトを解除）
    // origin: process.env.MAPKIT_ORIGIN,
  };

  const encHeader  = base64urlEncode(JSON.stringify(header));
  const encPayload = base64urlEncode(JSON.stringify(payload));
  const signingInput = `${encHeader}.${encPayload}`;

  // p8 → PKCS#8 → CryptoKey
  const cryptoKey = await importP8Key(rawKey);

  // ES256 署名
  const signature = await crypto.subtle.sign(
    { name: 'ECDSA', hash: { name: 'SHA-256' } },
    cryptoKey,
    new TextEncoder().encode(signingInput)
  );

  const encSig = base64urlEncodeBuffer(signature);
  return `${signingInput}.${encSig}`;
}

// ── p8 PEM → CryptoKey ──
async function importP8Key(pem) {
  // PEM ヘッダー/フッターと改行を除去
  const pemBody = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, '')
    .replace(/-----END PRIVATE KEY-----/g, '')
    .replace(/\s+/g, '');

  const der = base64Decode(pemBody);

  return crypto.subtle.importKey(
    'pkcs8',
    der,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign']
  );
}

// ── ユーティリティ ──
function base64urlEncode(str) {
  const b64 = btoa(unescape(encodeURIComponent(str)));
  return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function base64urlEncodeBuffer(buf) {
  const bytes = new Uint8Array(buf);
  let b64 = '';
  for (let i = 0; i < bytes.length; i++) {
    b64 += String.fromCharCode(bytes[i]);
  }
  return btoa(b64).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function base64Decode(b64) {
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
}
